# Optimizing a Website for Search Ranking

Starting source for Optimizing a Website for Search Ranking lab.
